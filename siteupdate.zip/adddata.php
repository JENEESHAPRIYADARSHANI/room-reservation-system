<?php
 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
    // collect value of input field
    $title = $_REQUEST['title'];
    $name = $_REQUEST['name'];
    $email = $_REQUEST['email'];
    $phone = $_REQUEST['phone'];
    $checkin = $_REQUEST['check-in'];
    $checkout = $_REQUEST['check-out'];
    $roomtype = $_REQUEST['roomtype'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ovinray";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO guests (roomtype, title, name,email,phone,checkin,checkout)
VALUES ('$roomtype', '$title', '$name','$email','$phone','$checkin','$checkout')";

if ($conn->query($sql) === TRUE) {
   echo "<script>location.href='home.html';</script>";
} else {
    echo "<script>location.href='home.html';</script>";
}

$conn->close();
}
?>


