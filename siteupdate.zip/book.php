<?php
require_once "config.php";
require_once "validate.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $name = $_POST['name'];
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $roomtype = $_POST['roomtype'];

    if($roomtype=='delux'){
        $sql = "INSERT INTO deluxroom (title, name, email,phone,checkin,checkout)
        VALUES ('$title', '$name', '$email','$phone','$checkin','$checkout')";

        $sql2="DELETE FROM guests WHERE id='$id'";

        $sql3="SELECT COUNT(*) as count FROM deluxroom";
        $count=0;
        $result = $conn->query($sql3);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
              $count=$row["count"];
            }
          } else {
            
          }
          //echo $count;
        if($count<10){
        if ($conn->query($sql) === TRUE && $conn->query($sql2) === TRUE) {
          echo "New record created successfully";
        } else {
          echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    else{echo "Rooms are Filled Please Check Out"; }
        
        $conn->close();
    }



    if($roomtype=='normal'){
        $sql = "INSERT INTO normalroomm (title, name, email,phone,checkin,checkout)
        VALUES ('$title', '$name', '$email','$phone','$checkin','$checkout')";

        $sql2="DELETE FROM guests WHERE id='$id'";

        $sql3="SELECT COUNT(*) as count FROM normalroomm";
        $count=0;
        $result = $conn->query($sql3);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
              $count=$row["count"];
            }
          } else {
            
          }
          //echo $count;
        if($count<10){
        if ($conn->query($sql) === TRUE && $conn->query($sql2) === TRUE) {
          echo "New record created successfully";
        } else {
          echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    else{echo "Rooms are Filled Please Check Out"; }
        
        $conn->close();
    }

    if($roomtype=='standard'){
        $sql = "INSERT INTO standardroom (title, name, email,phone,checkin,checkout)
        VALUES ('$title', '$name', '$email','$phone','$checkin','$checkout')";

        $sql2="DELETE FROM guests WHERE id='$id'";

        $sql3="SELECT COUNT(*) as count FROM standardroom";
        $count=0;
        $result = $conn->query($sql3);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
              $count=$row["count"];
            }
          } else {
            
          }
          //echo $count;
        if($count<10){
        if ($conn->query($sql) === TRUE && $conn->query($sql2) === TRUE) {
          echo "New record created successfully";
        } else {
          echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    else{echo "Rooms are Filled Please Check Out"; }
        
        $conn->close();
    }


}
echo "<script>location.href='dashboard.php';</script>";
?>

