<?php
require_once "config.php";
require_once "validate.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $email = $_POST['email'];
    $roomtype = $_POST['roomtype'];

    if($roomtype=='delux'){
$sql = "DELETE FROM deluxroom WHERE id='$id'";

if ($conn->query($sql) === TRUE) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . $conn->error;
}
    }

    if($roomtype=='normal'){
        $sql = "DELETE FROM normalroomm WHERE id='$id'";
        
        if ($conn->query($sql) === TRUE) {
          echo "Record deleted successfully";
        } else {
          echo "Error deleting record: " . $conn->error;
        }
            }

            if($roomtype=='standard'){
                $sql = "DELETE FROM standardroom WHERE id='$id'";
                
                if ($conn->query($sql) === TRUE) {
                  echo "Record deleted successfully";
                } else {
                  echo "Error deleting record: " . $conn->error;
                }
                    }
                    echo "<script>location.href='dashboard.php';</script>";


                    
                  
}
?>